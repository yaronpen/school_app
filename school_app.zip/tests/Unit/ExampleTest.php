<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\User;

// class ExampleTest extends TestCase
// {
    /**
     * A basic test example.
     *
     * @return void
     */
    // public function regiser_teacher()
    // {
    //     $user = [
    //       "username" => "doe",
    //       "email" => "coral@gmail.com",
    //       "password" => "123456",
    //       "fullname" => "John Doe"
    //     ];
    //
    //     $response = $this->withHeaders([
    //         'Content-Type' => 'application/json',
    //         'Cache-Control' => 'no-cache'
    //     ])->post('/api/create/teacher', $user);
    //
    //     // $response->assertStatus(201);
    // }
// }
